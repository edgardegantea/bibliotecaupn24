
<div class="col-12 px-4 py-5 my-5 text-center" style="background-color: #04328C; height: 600px; display: flex; align-items: center; justify-content: center;">
    <div> 
        <h1 class="display-5 fw-bold text-light">Buscar</h1>
        <div class="col-lg-12 mx-auto">
            <p class="lead text-light">Realizar búsqueda de recursos bibliográficos</p>
            <div class="d-grid gap-2 col-12 d-sm-flex justify-content-sm-center">
                <input type="search" name="buscar" class="form-control col-10" id="">
                <button type="button" class="btn btn-primary btn-lg px-4 gap-3">Buscar</button>
            </div>
        </div>
    </div>
</div>






