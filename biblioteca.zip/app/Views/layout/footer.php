<!--begin::Footer-->
<footer class="app-footer"> <!--begin::To the end-->
    <div class="float-end d-none d-sm-inline">Developed by <strong><a href="https://mapaches.info/edgardegantea" target="_blank" class="text-decoration-none">edegantea</a></strong>
        for <a href="https://upn212tez.info" target="_blank" class="text-decoration-none">UPN212-Teziutlán</a></strong>. <?= date('Y'); ?>.
    </div>
</footer> <!--end::Footer-->